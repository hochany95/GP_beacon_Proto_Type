From https://github.com/akexorcist/Android-LocalizationActivity
Commit 3001ec8ea57f87e6709bc104b0cd7e4016ec8031
Version 1.1.1