CHANGES
=======

1.8 (2016-06-17)
----------------

- Added `EddystoneEID`.


1.7 (2016-01-29)
----------------

- Added `StandardGattService`.
- Moved `GattStatusCode` from `com.neovisionaries.bluetooth.ble.util`
  package to `com.neovisionaries.bluetooth.blu` package.
